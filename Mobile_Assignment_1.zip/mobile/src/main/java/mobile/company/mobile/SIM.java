package mobile.company.mobile;

public interface SIM {
    void phoneCall();
}


