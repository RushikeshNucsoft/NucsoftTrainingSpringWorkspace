package mobile.company.mobile;

public class VI implements SIM {
    @Override
    public void phoneCall() {
        System.out.println("Making a phone call using VI SIM.");
    }
}