package com.example.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.employee.entity.Employee;

@Autowired
private EmployeeService employeeService;


@Controller
@RequestMapping("/api")
public class EmployeeController {
    // Autowire EmployeeService or EmployeeRepository

    @PostMapping("/employees")
    public ResponseEntity<Employee> createEmployee(@RequestBody Employee employee) {
    	  Employee createdEmployee = employeeService.createEmployee(employee);
          return ResponseEntity.status(HttpStatus.CREATED).body(createdEmployee);
    }

    @GetMapping("/employees")
    public ResponseEntity<List<Employee>> getAllEmployees() {
    	   List<Employee> employees = employeeService.getAllEmployees();
           return ResponseEntity.ok(employees);
    }

    @GetMapping("/employees")
    public ResponseEntity<List<Employee>> getEmployeesByAgeAndCity(
    	    @RequestParam("age") int age,
            @RequestParam("city") String city) {
        List<Employee> employees = employeeService.getEmployeesByAgeAndCity(age, city);
        return ResponseEntity.ok(employees);
    }

    @PutMapping("/employees/{id}")
    public ResponseEntity<Employee> updateEmployee(
    		   @PathVariable("id") long id,
               @RequestBody Employee updatedEmployee) {
           Employee employee = employeeService.updateEmployee(id, updatedEmployee);
           return ResponseEntity.ok(employee);
    }

    @DeleteMapping("/employees/{id}")
    public ResponseEntity<Void> deleteEmployee(@PathVariable("id") long id) {
    	  employeeService.deleteEmployee(id);
          return ResponseEntity.noContent().build();
    }
}

