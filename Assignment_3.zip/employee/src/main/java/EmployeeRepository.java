import org.springframework.stereotype.Repository;

@Repository
public class EmployeeRepository {
    // Code for database operations like save, findAll, findById, deleteById, etc.
}

